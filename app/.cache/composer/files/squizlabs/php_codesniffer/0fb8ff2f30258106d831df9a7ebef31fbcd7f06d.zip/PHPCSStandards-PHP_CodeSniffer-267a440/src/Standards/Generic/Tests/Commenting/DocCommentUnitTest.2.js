// Intentional parse error. Testing that the sniff is *not* triggered
// in this case

/** No docblock close tag. Must be last test without new line.